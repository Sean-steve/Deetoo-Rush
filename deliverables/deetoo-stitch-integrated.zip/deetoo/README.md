# Deetoo — Multi-Sided Food Delivery Platform

**Deetoo** is a production-grade multi-sided food delivery platform serving Kenya and East Africa. It connects Customers, Merchants, and Rider Couriers under a unified, high-reliability platform.

---

## Sprint 1: Foundation, Monorepo & Engineering Baseline

Sprint 1 establishes the rock-solid technical baseline before business feature implementation:
- **Monorepo Architecture**: Managed with `pnpm workspaces` and `Turborepo`.
- **Four Frontend Applications**:
  - `apps/customer`: Food discovery, address validation, order tracking.
  - `apps/merchant`: Restaurant kitchen console, prep-time management, store status.
  - `apps/rider`: Mobile-first courier shell, GPS telemetry, dispatch offers.
  - `apps/admin`: Operational oversight, PostGIS service zones, audit logs, ledger view.
- **Centralized Modular-Monolith API (`apps/api`)**:
  - Express-based REST API with standardized envelopes (`DEE-API-001`).
  - Correlation tracking with `X-Request-Id`.
  - Structured JSON logging.
  - Centralized error handler without information leakage.
  - Comprehensive health probes: `/health`, `/health/live`, `/health/ready`.
- **Shared Packages (`/packages/`)**:
  - `@deetoo/types`: Central domain interfaces, enums, API envelopes.
  - `@deetoo/validation`: Zod validation schemas.
  - `@deetoo/config`: Type-safe configuration with Zod validation.
  - `@deetoo/utils`: Safe integer financial math (minor units), structured logging, ID generators.
  - `@deetoo/auth`: Role-based access control matrix & permissions.
  - `@deetoo/api-client`: Unified API client with timeout, correlation ID, and retry policies.
  - `@deetoo/ui`: Design tokens (Deetoo Green `#00A651`) and component primitives.
  - `@deetoo/eslint-config`: Shared linting rules.
- **Database & Persistence**:
  - PostgreSQL 16 schema migrations (`001_initial_schema.sql`, `002_postgis_zones.sql`).
  - PostGIS 3.4 spatial containment (SRID 4326).
  - Double-Entry Ledger chart of accounts (`DEE-FIN-001`).
  - Redis 7 ephemeral caching with safe degradation failure policy.
- **Quality & CI/CD**:
  - Unit, Integration, and E2E Smoke test suites (`tests/`).
  - GitHub Actions CI workflow (`.github/workflows/ci.yml`).

---

## Quick Start

### 1. Start Infrastructure
```bash
docker-compose up -d
```

### 2. Run Database Migrations & Seeds
```bash
npm run db:migrate
npm run db:seed
```

### 3. Start Development Server
```bash
npm run dev
```

### 4. Run Verification Suite
```bash
npm test
npm run check-types
npm run lint
npm run build
```

---

## Architecture Documentation
- [ADR-001: Monorepo Structure](docs/architecture/ADR-001-monorepo-structure.md)
- [ADR-002: Modular Monolith](docs/architecture/ADR-002-modular-monolith.md)
- [ADR-003: PostGIS Spatial Queries](docs/architecture/ADR-003-postgis-geospatial-containment.md)
- [ADR-004: Immutable Double-Entry Ledger](docs/architecture/ADR-004-immutable-double-entry-ledger.md)
- [ADR-005: Redis Ephemeral Failure Policy](docs/architecture/ADR-005-redis-ephemeral-failure-policy.md)
- [Local Development Workflow](docs/development/local-setup.md)
- [AI Coding Conventions](docs/ai/conventions.md)
