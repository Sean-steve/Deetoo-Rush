/**
 * DEETOO - Central Configuration Layer
 * Typed access to settings with fail-fast validation
 * Based on Section 13 & 14
 */

export type AppEnvironment = 'development' | 'test' | 'staging' | 'production';
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface DeetooConfig {
  environment: AppEnvironment;
  isProduction: boolean;
  isDevelopment: boolean;
  isTest: boolean;
  port: number;
  api: {
    baseUrl: string;
    versionPrefix: string;
  };
  database: {
    url: string;
    maxConnections: number;
    idleTimeoutMs: number;
  };
  redis: {
    url: string;
    reconnectIntervalMs: number;
  };
  logging: {
    level: LogLevel;
  };
  security: {
    jwtSecret: string;
    jwtAccessTtlSeconds: number;
  };
  rider: {
    locationStaleSeconds: number;
    maxAccuracyMeters: number;
    foregroundUpdateIntervalMs: number;
    locationTtlSeconds: number;
    maxSpeedMps: number;
  };
  dispatch: {
    initialSearchRadius: number;
    radiusExpansionSteps: number[];
    maxSearchRadius: number;
    offerTimeoutSeconds: number;
    maxOffersPerCycle: number;
    retryIntervalsSeconds: number[];
    pickupArrivalBufferSeconds: number;
    expectedRiderPickupTravelTimeSeconds: number;
    maxActiveDeliveriesPerRider: number;
    routingCandidateLimit: number;
    dispatchSlaSeconds: number;
  };
  payment: {
    mpesa: {
      consumerKey: string;
      consumerSecret: string;
      passkey: string;
      shortcode: string;
      callbackUrl: string;
      webhookSecret: string;
      timeoutSeconds: number;
    };
    card: {
      publishableKey: string;
      secretKey: string;
      webhookSecret: string;
    };
    unpaidOrderTtlMinutes: number;
    enforcePrepayment: boolean;
  };
}

function resolveEnv(key: string, defaultValue?: string): string {
  const value = process.env[key] || defaultValue;
  if (value === undefined) {
    // Fail fast in production if required config missing
    if (process.env.NODE_ENV === 'production' && !defaultValue) {
      throw new Error(`[Deetoo Config] Fatal: Missing required environment variable ${key}`);
    }
    return '';
  }
  return value;
}

const rawEnv = (process.env.APP_ENV || process.env.NODE_ENV || 'development').toLowerCase();
const environment: AppEnvironment = ['development', 'test', 'staging', 'production'].includes(rawEnv)
  ? (rawEnv as AppEnvironment)
  : 'development';

export const config: DeetooConfig = {
  environment,
  isProduction: environment === 'production',
  isDevelopment: environment === 'development',
  isTest: environment === 'test',
  port: parseInt(process.env.PORT || '3000', 10),
  api: {
    baseUrl: resolveEnv('API_BASE_URL', 'http://localhost:3000/api/v1'),
    versionPrefix: '/api/v1',
  },
  database: {
    url: resolveEnv('DATABASE_URL', 'postgres://postgres:postgrespassword@localhost:5432/deetoo_dev'),
    maxConnections: parseInt(process.env.DATABASE_MAX_CONNECTIONS || '20', 10),
    idleTimeoutMs: parseInt(process.env.DATABASE_IDLE_TIMEOUT_MS || '30000', 10),
  },
  redis: {
    url: resolveEnv('REDIS_URL', 'redis://localhost:6379'),
    reconnectIntervalMs: 5000,
  },
  logging: {
    level: (process.env.LOG_LEVEL as LogLevel) || 'info',
  },
  security: {
    jwtSecret: resolveEnv('JWT_SECRET', 'deetoo_dev_jwt_secret_change_in_production_min_32_chars'),
    jwtAccessTtlSeconds: parseInt(process.env.JWT_ACCESS_TTL_SECONDS || '900', 10),
  },
  rider: {
    locationStaleSeconds: parseInt(process.env.RIDER_LOCATION_STALE_SECONDS || '90', 10),
    maxAccuracyMeters: parseInt(process.env.RIDER_MAX_ACCURACY_METERS || '100', 10),
    foregroundUpdateIntervalMs: parseInt(process.env.RIDER_FOREGROUND_UPDATE_INTERVAL_MS || '15000', 10),
    locationTtlSeconds: parseInt(process.env.RIDER_LOCATION_TTL_SECONDS || '180', 10),
    maxSpeedMps: parseInt(process.env.RIDER_MAX_SPEED_MPS || '45', 10),
  },
  dispatch: {
    initialSearchRadius: parseInt(process.env.DISPATCH_INITIAL_SEARCH_RADIUS || '2000', 10),
    radiusExpansionSteps: [2000, 4000, 6000],
    maxSearchRadius: parseInt(process.env.DISPATCH_MAX_SEARCH_RADIUS || '8000', 10),
    offerTimeoutSeconds: parseInt(process.env.DISPATCH_OFFER_TIMEOUT_SECONDS || '30', 10),
    maxOffersPerCycle: parseInt(process.env.DISPATCH_MAX_OFFERS_PER_CYCLE || '5', 10),
    retryIntervalsSeconds: [30, 60, 120],
    pickupArrivalBufferSeconds: parseInt(process.env.DISPATCH_PICKUP_ARRIVAL_BUFFER_SECONDS || '120', 10),
    expectedRiderPickupTravelTimeSeconds: parseInt(process.env.DISPATCH_EXPECTED_RIDER_PICKUP_TRAVEL_TIME_SECONDS || '480', 10),
    maxActiveDeliveriesPerRider: 1,
    routingCandidateLimit: parseInt(process.env.DISPATCH_ROUTING_CANDIDATE_LIMIT || '10', 10),
    dispatchSlaSeconds: parseInt(process.env.DISPATCH_SLA_SECONDS || '480', 10),
  },
  payment: {
    mpesa: {
      consumerKey: resolveEnv('MPESA_CONSUMER_KEY', 'sandbox_consumer_key'),
      consumerSecret: resolveEnv('MPESA_CONSUMER_SECRET', 'sandbox_consumer_secret'),
      passkey: resolveEnv('MPESA_PASSKEY', 'sandbox_passkey'),
      shortcode: resolveEnv('MPESA_SHORTCODE', '174379'),
      callbackUrl: resolveEnv('MPESA_CALLBACK_URL', 'http://localhost:3000/api/v1/payments/providers/mpesa/callback'),
      webhookSecret: resolveEnv('MPESA_WEBHOOK_SECRET', 'mpesa_webhook_secret_dev'),
      timeoutSeconds: parseInt(process.env.MPESA_TIMEOUT_SECONDS || '60', 10),
    },
    card: {
      publishableKey: resolveEnv('CARD_PUBLISHABLE_KEY', 'pk_test_sample'),
      secretKey: resolveEnv('CARD_SECRET_KEY', 'sk_test_sample'),
      webhookSecret: resolveEnv('CARD_WEBHOOK_SECRET', 'card_webhook_secret_dev'),
    },
    unpaidOrderTtlMinutes: parseInt(process.env.UNPAID_ORDER_TTL_MINUTES || '15', 10),
    enforcePrepayment: process.env.ENFORCE_PREPAYMENT === 'true',
  },
};
