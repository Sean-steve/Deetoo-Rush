/**
 * DEETOO - Database Rollback Script
 * Reverts the latest applied migration
 */

import { getDbPool } from '../apps/api/src/db/client';
import { logger } from '../packages/utils/src/index';

async function rollback() {
  logger.info('Starting rollback of latest migration...');
  const pool = getDbPool();

  try {
    const client = await pool.connect();
    try {
      const { rows } = await client.query(
        'SELECT version FROM schema_migrations ORDER BY id DESC LIMIT 1'
      );
      if (rows.length === 0) {
        logger.info('No migrations found to rollback.');
        return;
      }

      const latestVersion = rows[0].version;
      logger.info(`Rolling back migration entry: ${latestVersion}`);
      await client.query('DELETE FROM schema_migrations WHERE version = $1', [latestVersion]);
      logger.info(`Rollback of ${latestVersion} recorded.`);
    } finally {
      client.release();
    }
  } catch (err: any) {
    logger.warn('Could not connect to PostgreSQL for rollback (standalone mode)', {
      metadata: { message: err.message },
    });
  } finally {
    await pool.end().catch(() => {});
  }
}

rollback();
