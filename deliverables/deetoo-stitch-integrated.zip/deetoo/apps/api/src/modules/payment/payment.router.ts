/**
 * DEETOO - Payment & Refund REST Router
 * Implements M-PESA & Card initiation, webhooks/callbacks, customer status,
 * and administrative refund & reconciliation endpoints (Sprint 11).
 */

import { Router, Response, NextFunction } from 'express';
import { UserRole } from '@deetoo/types';
import { PaymentInitiateSchema, AdminRefundSchema, PaymentQueryFilterSchema } from '@deetoo/validation';
import { requireAuth, requireRole, AuthenticatedRequest } from '../auth/auth.middleware';
import { AppError } from '../../middleware/error-handler';
import { paymentService } from './payment.service';

export const paymentRouter = Router();

// ==========================================
// 1. Provider Webhook / Callback Ingress (Public)
// ==========================================

/**
 * POST /api/v1/payments/providers/mpesa/callback
 * Safaricom Daraja STK Push Callback URL
 */
paymentRouter.post('/providers/mpesa/callback', async (req, res: Response, next: NextFunction) => {
  try {
    const rawBody = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    const result = await paymentService.handleCallback('MPESA', req.headers as Record<string, string>, rawBody, req.body);

    // Standard Safaricom Daraja acknowledgement format
    return res.status(200).json({
      ResultCode: 0,
      ResultDesc: 'Callback processed successfully',
      PaymentId: result.paymentId,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/v1/payments/providers/card/webhook
 * Tokenized Card Webhook endpoint
 */
paymentRouter.post('/providers/card/webhook', async (req, res: Response, next: NextFunction) => {
  try {
    const rawBody = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    const result = await paymentService.handleCallback('CARD', req.headers as Record<string, string>, rawBody, req.body);

    return res.status(200).json({
      received: true,
      duplicate: result.duplicate,
      paymentId: result.paymentId,
    });
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 2. Customer Payment Endpoints (Authenticated)
// ==========================================

/**
 * POST /api/v1/payments/initiate
 * Initiate payment for an order via M-PESA STK Push or Card
 */
paymentRouter.post('/initiate', requireAuth, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const validated = PaymentInitiateSchema.parse(req.body);
    const orderId = req.body.order_id || req.body.orderId;
    if (!orderId) {
      throw new AppError(400, 'ORDER_ID_REQUIRED', 'order_id is required to initiate payment');
    }

    const idempotencyKey = (req.headers['idempotency-key'] || req.headers['x-idempotency-key']) as string | undefined;

    const payment = await paymentService.initiatePayment({
      orderId,
      customerId: req.user!.id,
      method: validated.method,
      phone: validated.phone,
      paymentMethodToken: validated.payment_method_token,
      idempotencyKey,
    });

    return res.status(201).json({
      success: true,
      data: payment,
      message: 'Payment initiated successfully',
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/v1/payments/:id
 * Retrieve payment status by ID
 */
paymentRouter.get('/:id', requireAuth, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const payment = await paymentService.getPayment(req.params.id);
    if (!payment) {
      throw new AppError(404, 'PAYMENT_NOT_FOUND', 'Payment not found');
    }

    // Access control: customer can only view own payments unless admin/support
    const isStaffOrAdmin = req.user!.roles.some((r) =>
      [UserRole.ADMIN, UserRole.OPS, UserRole.SUPPORT].includes(r)
    );
    if (!isStaffOrAdmin && payment.customer_id !== req.user!.id) {
      throw new AppError(403, 'FORBIDDEN', 'Access to payment denied');
    }

    return res.status(200).json({
      success: true,
      data: payment,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/v1/payments/order/:orderId
 * Retrieve all payment attempts for an order
 */
paymentRouter.get('/order/:orderId', requireAuth, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const payments = await paymentService.getPaymentsByOrder(req.params.orderId);
    return res.status(200).json({
      success: true,
      data: payments,
    });
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 3. Admin & Support Operations
// ==========================================

/**
 * GET /api/v1/payments/admin/all
 * List payments with filters & pagination
 */
paymentRouter.get(
  '/admin/all',
  requireAuth,
  requireRole(UserRole.ADMIN, UserRole.OPS, UserRole.SUPPORT),
  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const filters = PaymentQueryFilterSchema.parse(req.query);
      const result = await paymentService.listPayments(filters);
      return res.status(200).json({
        success: true,
        data: result.payments,
        meta: {
          total: result.total,
          page: filters.page,
          limit: filters.limit,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/v1/payments/admin/:id/refunds
 * Process refund (full or partial)
 */
paymentRouter.post(
  '/admin/:id/refunds',
  requireAuth,
  requireRole(UserRole.ADMIN, UserRole.OPS, UserRole.SUPPORT),
  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const validated = AdminRefundSchema.parse(req.body);
      const refund = await paymentService.requestRefund({
        paymentId: req.params.id,
        amountMinor: validated.amount_minor,
        amount: validated.amount,
        reasonCode: validated.reason_code,
        note: validated.note,
        requestedBy: req.user!.id,
      });

      return res.status(201).json({
        success: true,
        data: refund,
        message: 'Refund processed successfully',
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * GET /api/v1/payments/admin/:id/refunds
 * List refunds for a payment
 */
paymentRouter.get(
  '/admin/:id/refunds',
  requireAuth,
  requireRole(UserRole.ADMIN, UserRole.OPS, UserRole.SUPPORT),
  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const refunds = await paymentService.getRefundsByPayment(req.params.id);
      return res.status(200).json({
        success: true,
        data: refunds,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/v1/payments/admin/:id/reconcile
 * Trigger payment reconciliation against provider
 */
paymentRouter.post(
  '/admin/:id/reconcile',
  requireAuth,
  requireRole(UserRole.ADMIN, UserRole.OPS),
  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const reconciled = await paymentService.reconcilePayment(req.params.id);
      return res.status(200).json({
        success: true,
        data: reconciled,
        message: 'Payment successfully reconciled',
      });
    } catch (error) {
      next(error);
    }
  }
);
