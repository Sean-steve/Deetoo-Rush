/**
 * DEETOO - Core Payment Domain Service
 * Orchestrates payment lifecycle, provider delegation, state machine enforcement,
 * idempotent callbacks, order reconciliation, and refund operations (Sprint 11).
 */

import crypto from 'crypto';
import {
  Payment,
  PaymentStatus,
  PaymentMethod,
  PaymentProvider,
  PaymentReconciliationStatus,
  Refund,
  RefundStatus,
  RefundReasonCode,
  OrderStatus,
} from '@deetoo/types';
import { config } from '@deetoo/config';
import { logger } from '@deetoo/utils';
import { AppError } from '../../middleware/error-handler';
import { paymentRepository } from './payment.repository';
import { PaymentStateMachine } from './payment.state-machine';
import { paymentProviderRegistry } from './providers/provider-registry';
import { orderRepository } from '../order/order.repository';
import { orderEventBroker } from '../realtime/event-broker';
import { financialPostingService } from '../finance/financial-posting.service';

export interface InitiatePaymentParams {
  orderId: string;
  customerId: string;
  method: 'MPESA' | 'CARD';
  phone?: string;
  paymentMethodToken?: string;
  idempotencyKey?: string;
}

export interface AdminRefundParams {
  paymentId: string;
  amountMinor?: number;
  amount?: number;
  reasonCode: RefundReasonCode | string;
  reasonCategory?: string;
  note?: string;
  requestedBy: string;
}

export class PaymentService {
  /**
   * Initiates payment for an order with strict idempotency and pre-payment validation
   */
  public async initiatePayment(params: InitiatePaymentParams): Promise<Payment> {
    const { orderId, customerId, method, phone, paymentMethodToken, idempotencyKey } = params;

    // 1. Validate Order exists & belongs to customer
    const order = await orderRepository.findById(orderId);
    if (!order) {
      throw new AppError(404, 'ORDER_NOT_FOUND', `Order ${orderId} does not exist`);
    }

    if (order.customer_id !== customerId) {
      throw new AppError(403, 'FORBIDDEN_ORDER_ACCESS', 'You do not have access to pay for this order');
    }

    // 2. Order status eligibility check
    if (order.status === OrderStatus.CANCELLED || order.status === OrderStatus.REJECTED) {
      throw new AppError(400, 'ORDER_ALREADY_CANCELLED', `Cannot pay for ${order.status.toLowerCase()} order`);
    }

    if (order.status === OrderStatus.COMPLETED) {
      throw new AppError(400, 'ORDER_ALREADY_COMPLETED', 'Completed orders cannot initiate new payments');
    }

    // 3. Idempotency Check
    const effectiveKey = idempotencyKey || `idem_${orderId}_${method}_${phone || ''}`;
    const requestHash = crypto
      .createHash('sha256')
      .update(JSON.stringify({ orderId, customerId, method, phone, amountMinor: order.total_minor }))
      .digest('hex');

    const existingIdem = await paymentRepository.getIdempotencyRecord(effectiveKey);
    if (existingIdem) {
      const existingPayment = await paymentRepository.findPaymentById(existingIdem.paymentId);
      if (existingPayment) {
        // If already captured or currently pending, return existing payment
        if (
          existingPayment.status === PaymentStatus.CAPTURED ||
          existingPayment.status === PaymentStatus.PENDING ||
          existingPayment.status === PaymentStatus.INITIATED
        ) {
          logger.info('Idempotent payment initiation returned', {
            service: 'payment-service',
            metadata: { orderId, paymentId: existingPayment.id },
          });
          return existingPayment;
        }
      }
    }

    // 4. Duplicate payment check (prevent multiple successful captures for same order)
    const existingPayments = await paymentRepository.findPaymentsByOrderId(orderId);
    const alreadyCaptured = existingPayments.find(
      (p) => p.status === PaymentStatus.CAPTURED || p.status === PaymentStatus.PARTIALLY_REFUNDED
    );
    if (alreadyCaptured) {
      throw new AppError(400, 'ORDER_ALREADY_PAID', 'This order has already been successfully paid');
    }

    // 5. Create Payment entity
    const paymentId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const providerKey = method === 'MPESA' ? 'MPESA' : 'CARD';
    const provider = paymentProviderRegistry.getProvider(providerKey);

    const initialPayment: Payment = {
      id: paymentId,
      order_id: orderId,
      customer_id: customerId,
      provider: providerKey as PaymentProvider,
      method: method as PaymentMethod,
      status: PaymentStatus.INITIATED,
      currency: order.currency || 'KES',
      amount_minor: order.total_minor,
      amount: order.total_minor / 100,
      captured_minor: 0,
      refunded_minor: 0,
      phone: phone || null,
      reconciliation_status: PaymentReconciliationStatus.UNRECONCILED,
      idempotency_key: effectiveKey,
      initiated_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    // Save initial state and append timeline
    const saved = await paymentRepository.savePayment(initialPayment);
    await paymentRepository.appendPaymentTimeline({
      payment_id: saved.id,
      event_type: 'PAYMENT_INITIATED',
      from_status: null,
      to_status: PaymentStatus.INITIATED,
      metadata: { method, phone, amountMinor: order.total_minor },
    });

    // Save idempotency key
    await paymentRepository.saveIdempotencyRecord({
      idempotencyKey: effectiveKey,
      customerId,
      orderId,
      requestHash,
      paymentId: saved.id,
      createdAt: new Date().toISOString(),
    });

    // 6. Delegate to provider adapter
    try {
      const result = await provider.initiatePayment({
        paymentId: saved.id,
        orderId,
        orderNumber: order.order_number,
        amountMinor: order.total_minor,
        currency: saved.currency,
        phone,
        paymentMethodToken,
        idempotencyKey: effectiveKey,
      });

      if (!result.success) {
        saved.status = PaymentStatus.FAILED;
        saved.failure_code = 'PROVIDER_INITIATION_FAILED';
        saved.failure_message = result.responseDescription || 'Failed to initiate payment';
        saved.failed_at = new Date().toISOString();
        await paymentRepository.updatePayment(saved);
        await paymentRepository.appendPaymentTimeline({
          payment_id: saved.id,
          event_type: 'PAYMENT_INITIATION_FAILED',
          from_status: PaymentStatus.INITIATED,
          to_status: PaymentStatus.FAILED,
          reason_code: saved.failure_code,
          metadata: result.rawResponse,
        });
        throw new AppError(502, 'PAYMENT_INITIATION_FAILED', saved.failure_message);
      }

      // Transition to PENDING
      PaymentStateMachine.validatePaymentTransition(saved.status, PaymentStatus.PENDING);
      saved.status = PaymentStatus.PENDING;
      saved.provider_payment_id = result.providerPaymentId || null;
      saved.provider_reference = result.providerReference || null;
      saved.merchant_request_id = result.merchantRequestId || null;
      saved.checkout_request_id = result.checkoutRequestId || null;
      await paymentRepository.updatePayment(saved);

      await paymentRepository.appendPaymentTimeline({
        payment_id: saved.id,
        event_type: 'PAYMENT_PENDING',
        from_status: PaymentStatus.INITIATED,
        to_status: PaymentStatus.PENDING,
        provider_reference: result.providerReference,
        metadata: result.rawResponse,
      });

      // 7. Publish Real-time Event
      await this.publishPaymentEvents(saved, 'payment.initiated', order.branch_id);

      return saved;
    } catch (err: any) {
      if (err instanceof AppError) throw err;
      saved.status = PaymentStatus.FAILED;
      saved.failure_code = 'PROVIDER_ERROR';
      saved.failure_message = err.message;
      saved.failed_at = new Date().toISOString();
      await paymentRepository.updatePayment(saved);
      throw new AppError(502, 'PAYMENT_PROVIDER_ERROR', err.message);
    }
  }

  /**
   * Processes inbound webhook/callback from M-PESA or Card provider
   * Idempotent, verify authenticity, prevents state regression
   */
  public async handleCallback(
    providerId: string,
    headers: Record<string, string | string[] | undefined>,
    rawBody: string | unknown,
    payload: unknown
  ): Promise<{ acknowledged: boolean; duplicate?: boolean; paymentId?: string }> {
    const provider = paymentProviderRegistry.getProvider(providerId);

    // 1. Signature & Webhook Verification
    const isAuthentic = provider.verifyCallback(headers, rawBody);
    if (!isAuthentic) {
      logger.warn('Unauthorized payment webhook rejected', {
        service: 'payment-service',
        metadata: { providerId },
      });
      throw new AppError(401, 'INVALID_WEBHOOK_SIGNATURE', 'Payment webhook verification failed');
    }

    // 2. Parse provider-specific callback
    const parsed = provider.parseCallback(payload);
    if (!parsed.isValid) {
      logger.warn('Malformed payment callback payload', {
        service: 'payment-service',
        metadata: { providerId, payload },
      });
      return { acknowledged: true };
    }

    // 3. Deduplication check via payment_provider_events
    const payloadHash = crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex');
    const existingEvent = await paymentRepository.findProviderEvent(providerId, parsed.providerEventId);
    if (existingEvent && existingEvent.processing_status === 'PROCESSED') {
      logger.info('Duplicate payment callback ignored', {
        service: 'payment-service',
        metadata: { providerId, eventId: parsed.providerEventId },
      });
      return { acknowledged: true, duplicate: true, paymentId: existingEvent.payment_id || undefined };
    }

    // 4. Find matching payment record
    let payment: Payment | null = null;
    if (parsed.checkoutRequestId) {
      payment = await paymentRepository.findPaymentByCheckoutRequestId(parsed.checkoutRequestId);
    }
    if (!payment && parsed.merchantRequestId) {
      payment = await paymentRepository.findPaymentByMerchantRequestId(parsed.merchantRequestId);
    }
    if (!payment && parsed.providerReference) {
      payment = await paymentRepository.findPaymentByProviderReference(providerId, parsed.providerReference);
    }

    // Record incoming provider event
    const recordedEvent = await paymentRepository.recordProviderEvent({
      provider: providerId,
      provider_event_id: parsed.providerEventId,
      payment_id: payment?.id || null,
      event_type: parsed.eventType,
      payload_hash: payloadHash,
      raw_payload: (payload as Record<string, unknown>) || {},
      processing_status: 'RECEIVED',
    });

    if (!payment) {
      logger.warn('Payment callback received for unknown payment reference', {
        service: 'payment-service',
        metadata: { parsed },
      });
      recordedEvent.processing_status = 'FAILED';
      recordedEvent.processed_at = new Date().toISOString();
      await paymentRepository.recordProviderEvent(recordedEvent);
      return { acknowledged: true };
    }

    // 5. State Machine Evaluation & State Regression Protection
    const currentStatus = payment.status;
    let targetStatus: PaymentStatus;

    if (parsed.status === 'SUCCESS') {
      targetStatus = PaymentStatus.CAPTURED;
    } else if (parsed.status === 'CANCELLED') {
      targetStatus = PaymentStatus.CANCELLED;
    } else {
      targetStatus = PaymentStatus.FAILED;
    }

    // Regression check: If already CAPTURED, ignore late failure/cancelled callbacks!
    if (
      (currentStatus === PaymentStatus.CAPTURED || currentStatus === PaymentStatus.PARTIALLY_REFUNDED) &&
      targetStatus !== PaymentStatus.CAPTURED
    ) {
      logger.warn('Ignored regression transition on already captured payment', {
        service: 'payment-service',
        metadata: { paymentId: payment.id, currentStatus, attemptedStatus: targetStatus },
      });
      recordedEvent.processing_status = 'PROCESSED';
      recordedEvent.processed_at = new Date().toISOString();
      await paymentRepository.recordProviderEvent(recordedEvent);
      return { acknowledged: true, paymentId: payment.id };
    }

    // Validate transition
    if (PaymentStateMachine.canTransitionPayment(currentStatus, targetStatus)) {
      payment.status = targetStatus;

      if (targetStatus === PaymentStatus.CAPTURED) {
        payment.captured_minor = parsed.amountMinor || payment.amount_minor;
        payment.captured_at = new Date().toISOString();
        payment.reconciliation_status = PaymentReconciliationStatus.MATCHED;
        if (parsed.receiptNumber) {
          payment.mpesa_receipt_number = parsed.receiptNumber;
          payment.provider_reference = parsed.receiptNumber;
        }
      } else if (targetStatus === PaymentStatus.FAILED || targetStatus === PaymentStatus.CANCELLED) {
        payment.failed_at = new Date().toISOString();
        payment.failure_code = parsed.failureCode || 'PAYMENT_FAILED';
        payment.failure_message = parsed.failureMessage || 'Payment declined or cancelled';
      }

      await paymentRepository.updatePayment(payment);

      await paymentRepository.appendPaymentTimeline({
        payment_id: payment.id,
        event_type: `PAYMENT_${targetStatus}`,
        from_status: currentStatus,
        to_status: targetStatus,
        provider_reference: parsed.receiptNumber || parsed.providerReference,
        reason_code: parsed.failureCode,
        metadata: parsed.rawPayload,
      });

      // 6. Update order status if payment captured
      const order = await orderRepository.findById(payment.order_id);
      if (order && targetStatus === PaymentStatus.CAPTURED) {
        // Post to authoritative double-entry financial ledger (Sprint 12)
        try {
          await financialPostingService.postPaymentCapture(payment, order);
          payment.reconciliation_status = PaymentReconciliationStatus.MATCHED;
          await paymentRepository.updatePayment(payment);
        } catch (finErr) {
          logger.error('Failed to post captured payment to financial ledger', { error: finErr });
        }

        // If order was in PLACED or CREATED, log event and update order timeline
        await orderRepository.updateOrderStatus(order.id, order.status, {}, {
          id: `tl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          order_id: order.id,
          from_status: order.status,
          to_status: order.status,
          actor_type: 'CUSTOMER',
          actor_id: payment.customer_id,
          reason_code: 'PAYMENT_CAPTURED',
          note: `Payment captured: ${payment.currency} ${(payment.captured_minor / 100).toFixed(2)} (Ref: ${payment.mpesa_receipt_number || payment.provider_reference})`,
          created_at: new Date().toISOString(),
        });
      }

      // 7. Publish Real-time Order Events
      const eventTopic = targetStatus === PaymentStatus.CAPTURED ? 'payment.captured' : 'payment.failed';
      await this.publishPaymentEvents(payment, eventTopic, order?.branch_id);
    }

    recordedEvent.processing_status = 'PROCESSED';
    recordedEvent.processed_at = new Date().toISOString();
    await paymentRepository.recordProviderEvent(recordedEvent);

    return { acknowledged: true, paymentId: payment.id };
  }

  /**
   * Request refund for a captured payment (Admin / Support)
   * Enforces refund limits and partial refund calculations
   */
  public async requestRefund(params: AdminRefundParams): Promise<Refund> {
    const { paymentId, reasonCode, note, requestedBy } = params;

    const payment = await paymentRepository.findPaymentById(paymentId);
    if (!payment) {
      throw new AppError(404, 'PAYMENT_NOT_FOUND', `Payment ${paymentId} not found`);
    }

    // Must be in a refundable state
    if (payment.status !== PaymentStatus.CAPTURED && payment.status !== PaymentStatus.PARTIALLY_REFUNDED) {
      throw new AppError(
        400,
        'PAYMENT_NOT_REFUNDABLE',
        `Cannot refund payment in status ${payment.status}. Only CAPTURED payments can be refunded.`
      );
    }

    const availableRefundMinor = payment.captured_minor - payment.refunded_minor;
    if (availableRefundMinor <= 0) {
      throw new AppError(400, 'REFUND_LIMIT_EXCEEDED', 'Payment has already been fully refunded');
    }

    // Determine refund amount in minor units
    let refundAmountMinor: number;
    if (params.amountMinor) {
      refundAmountMinor = params.amountMinor;
    } else if (params.amount) {
      refundAmountMinor = Math.round(params.amount * 100);
    } else {
      // Default to full remaining balance
      refundAmountMinor = availableRefundMinor;
    }

    if (refundAmountMinor <= 0) {
      throw new AppError(400, 'INVALID_REFUND_AMOUNT', 'Refund amount must be greater than zero');
    }

    if (refundAmountMinor > availableRefundMinor) {
      throw new AppError(
        400,
        'REFUND_EXCEEDS_AVAILABLE_BALANCE',
        `Requested refund of ${refundAmountMinor} minor units exceeds available refundable balance of ${availableRefundMinor}`
      );
    }

    // Create Refund record
    const refundId = `ref_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const refund: Refund = {
      id: refundId,
      payment_id: payment.id,
      order_id: payment.order_id,
      amount_minor: refundAmountMinor,
      currency: payment.currency,
      status: RefundStatus.REQUESTED,
      reason_code: reasonCode as RefundReasonCode,
      note: note || null,
      requested_by: requestedBy,
      requested_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    await paymentRepository.saveRefund(refund);
    await paymentRepository.appendRefundTimeline({
      refund_id: refund.id,
      from_status: null,
      to_status: RefundStatus.REQUESTED,
      reason_code: String(reasonCode),
      metadata: { requestedBy, note },
    });

    // Delegate to payment provider for reversal / refund
    const provider = paymentProviderRegistry.getProvider(payment.provider);
    try {
      const providerResult = await provider.refund({
        refundId: refund.id,
        paymentId: payment.id,
        providerPaymentId: payment.provider_payment_id || undefined,
        providerReference: payment.provider_reference || undefined,
        amountMinor: refundAmountMinor,
        currency: payment.currency,
        reason: String(reasonCode),
        phone: payment.phone || undefined,
      });

      if (providerResult.success) {
        refund.status = RefundStatus.SUCCEEDED;
        refund.provider_refund_id = providerResult.providerRefundId || null;
        refund.processed_at = new Date().toISOString();
        await paymentRepository.updateRefund(refund);

        // Post refund reversal to double-entry financial ledger (Sprint 12)
        try {
          const refundOrder = await orderRepository.findById(payment.order_id);
          const isMerchantFault =
            reasonCode === RefundReasonCode.MERCHANT_REJECTED ||
            reasonCode === RefundReasonCode.ITEM_MISSING;

          await financialPostingService.postRefundReversal(refund, {
            merchantId: refundOrder?.merchant_id,
            isMerchantFault,
          });
        } catch (finErr) {
          logger.error('Failed to post refund reversal to financial ledger', { error: finErr });
        }

        await paymentRepository.appendRefundTimeline({
          refund_id: refund.id,
          from_status: RefundStatus.REQUESTED,
          to_status: RefundStatus.SUCCEEDED,
          reason_code: String(reasonCode),
          metadata: providerResult.rawResponse,
        });

        // Update payment refunded totals and status
        payment.refunded_minor += refundAmountMinor;
        if (payment.refunded_minor >= payment.captured_minor) {
          payment.status = PaymentStatus.REFUNDED;
          payment.refunded_at = new Date().toISOString();
        } else {
          payment.status = PaymentStatus.PARTIALLY_REFUNDED;
        }

        await paymentRepository.updatePayment(payment);

        await paymentRepository.appendPaymentTimeline({
          payment_id: payment.id,
          event_type: 'PAYMENT_REFUNDED',
          from_status: PaymentStatus.CAPTURED,
          to_status: payment.status,
          provider_reference: providerResult.providerRefundId,
          reason_code: String(reasonCode),
          metadata: { refundId: refund.id, refundAmountMinor },
        });

        // Update order timeline
        const order = await orderRepository.findById(payment.order_id);
        if (order) {
          await orderRepository.updateOrderStatus(order.id, order.status, {}, {
            id: `tl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            order_id: order.id,
            from_status: order.status,
            to_status: order.status,
            actor_type: 'ADMIN',
            actor_id: requestedBy,
            reason_code: 'PAYMENT_REFUNDED',
            note: `Refund issued: ${payment.currency} ${(refundAmountMinor / 100).toFixed(2)} (${reasonCode})`,
            created_at: new Date().toISOString(),
          });
        }

        // Publish events
        await this.publishPaymentEvents(payment, 'refund.succeeded', order?.branch_id);

        return refund;
      } else {
        refund.status = RefundStatus.FAILED;
        refund.failed_at = new Date().toISOString();
        await paymentRepository.updateRefund(refund);
        await paymentRepository.appendRefundTimeline({
          refund_id: refund.id,
          from_status: RefundStatus.REQUESTED,
          to_status: RefundStatus.FAILED,
          reason_code: providerResult.failureCode,
          metadata: providerResult.rawResponse,
        });
        throw new AppError(502, 'REFUND_PROCESSING_FAILED', providerResult.failureMessage || 'Refund failed');
      }
    } catch (err: any) {
      if (err instanceof AppError) throw err;
      refund.status = RefundStatus.FAILED;
      refund.failed_at = new Date().toISOString();
      await paymentRepository.updateRefund(refund);
      throw new AppError(502, 'REFUND_PROVIDER_ERROR', err.message);
    }
  }

  /**
   * Reconciles an unreconciled payment or queries provider status (Admin)
   */
  public async reconcilePayment(paymentId: string): Promise<Payment> {
    const payment = await paymentRepository.findPaymentById(paymentId);
    if (!payment) {
      throw new AppError(404, 'PAYMENT_NOT_FOUND', `Payment ${paymentId} not found`);
    }

    const provider = paymentProviderRegistry.getProvider(payment.provider);
    const queryRef = payment.checkout_request_id || payment.provider_reference || payment.id;
    const queryResult = await provider.queryStatus(queryRef, {
      merchantRequestId: payment.merchant_request_id,
    });

    if (queryResult.status === 'CAPTURED' && payment.status !== PaymentStatus.CAPTURED) {
      PaymentStateMachine.validatePaymentTransition(payment.status, PaymentStatus.CAPTURED);
      payment.status = PaymentStatus.CAPTURED;
      payment.captured_minor = queryResult.amountMinor || payment.amount_minor;
      payment.captured_at = new Date().toISOString();
      payment.reconciliation_status = PaymentReconciliationStatus.MATCHED;
      if (queryResult.receiptNumber) {
        payment.mpesa_receipt_number = queryResult.receiptNumber;
      }
      await paymentRepository.updatePayment(payment);
      await paymentRepository.appendPaymentTimeline({
        payment_id: payment.id,
        event_type: 'PAYMENT_RECONCILED',
        from_status: payment.status,
        to_status: PaymentStatus.CAPTURED,
        provider_reference: queryResult.providerReference,
        metadata: queryResult.rawResponse,
      });
    } else {
      payment.reconciliation_status = PaymentReconciliationStatus.MATCHED;
      await paymentRepository.updatePayment(payment);
    }

    return payment;
  }

  public async getPayment(paymentId: string): Promise<Payment | null> {
    return paymentRepository.findPaymentById(paymentId);
  }

  public async getPaymentsByOrder(orderId: string): Promise<Payment[]> {
    return paymentRepository.findPaymentsByOrderId(orderId);
  }

  public async listPayments(params: any): Promise<{ payments: Payment[]; total: number }> {
    return paymentRepository.listPayments(params);
  }

  public async getRefundsByPayment(paymentId: string): Promise<Refund[]> {
    return paymentRepository.findRefundsByPaymentId(paymentId);
  }

  public async getRefundsByOrder(orderId: string): Promise<Refund[]> {
    return paymentRepository.findRefundsByOrderId(orderId);
  }

  /**
   * Helper to broadcast real-time events to all interested parties
   */
  private async publishPaymentEvents(
    payment: Payment,
    eventTopic: string,
    branchId?: string
  ): Promise<void> {
    const payload = {
      event: eventTopic,
      paymentId: payment.id,
      orderId: payment.order_id,
      status: payment.status,
      method: payment.method,
      amountMinor: payment.amount_minor,
      capturedMinor: payment.captured_minor,
      currency: payment.currency,
      mpesaReceiptNumber: payment.mpesa_receipt_number,
      timestamp: new Date().toISOString(),
    };

    const makeEvent = (channel: string) => ({
      type: eventTopic as any,
      channel,
      order_id: payment.order_id,
      order_number: '',
      status: 'PLACED' as any,
      timestamp: new Date().toISOString(),
      data: payload,
    });

    // 1. Order room
    await orderEventBroker.publish(`order:${payment.order_id}`, makeEvent(`order:${payment.order_id}`));
    // 2. Customer channel
    await orderEventBroker.publish(`customer:${payment.customer_id}`, makeEvent(`customer:${payment.customer_id}`));
    // 3. Merchant branch channel if applicable
    if (branchId) {
      await orderEventBroker.publish(`merchant-branch:${branchId}`, makeEvent(`merchant-branch:${branchId}`));
    }
    // 4. Admin operations channel
    await orderEventBroker.publish('admin:payments', makeEvent('admin:payments'));
    await orderEventBroker.publish('admin:orders', makeEvent('admin:orders'));
  }
}

export const paymentService = new PaymentService();
