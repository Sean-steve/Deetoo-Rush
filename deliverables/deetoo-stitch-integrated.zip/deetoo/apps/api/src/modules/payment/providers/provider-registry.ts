/**
 * DEETOO - Payment Provider Registry
 * Resolves appropriate provider adapter by ID or payment method
 */

import { IPaymentProvider } from './payment-provider.interface';
import { mpesaPaymentProvider } from './mpesa.provider';
import { cardPaymentProvider } from './card.provider';
import { AppError } from '../../../middleware/error-handler';

export class PaymentProviderRegistry {
  private providers = new Map<string, IPaymentProvider>();

  constructor() {
    this.register(mpesaPaymentProvider);
    this.register(cardPaymentProvider);
  }

  public register(provider: IPaymentProvider): void {
    this.providers.set(provider.providerId.toUpperCase(), provider);
  }

  public getProvider(providerOrMethod: string): IPaymentProvider {
    const key = (providerOrMethod || '').toUpperCase();
    const provider = this.providers.get(key);
    if (!provider) {
      throw new AppError(400, 'UNSUPPORTED_PAYMENT_PROVIDER', `No payment provider registered for: ${providerOrMethod}`);
    }
    return provider;
  }
}

export const paymentProviderRegistry = new PaymentProviderRegistry();
