/**
 * DEETOO - Merchant Settlement Service
 * Sprint 12: Merchant batch calculation, approval lifecycle, and settlement execution
 */

import { ledgerRepository, LedgerRepository } from './ledger.repository';
import { financialPostingService, FinancialPostingService } from './financial-posting.service';
import {
  MerchantSettlement,
  MerchantSettlementStatus,
  MerchantSettlementLine,
  LedgerAccountType,
  LedgerAccountOwnerType,
} from '@deetoo/types';
import { logger } from '@deetoo/utils';

export class SettlementService {
  constructor(
    private repo: LedgerRepository = ledgerRepository,
    private postingSvc: FinancialPostingService = financialPostingService
  ) {}

  /**
   * Calculates a merchant settlement batch for a given period
   */
  public async calculateSettlement(
    merchantId: string,
    periodStart?: string,
    periodEnd?: string
  ): Promise<MerchantSettlement> {
    const end = periodEnd ? new Date(periodEnd) : new Date();
    const start = periodStart ? new Date(periodStart) : new Date(end.getTime() - 7 * 24 * 60 * 60 * 1000); // default last 7 days

    // Get merchant payable account
    const merchantAcc = await this.repo.getOrCreateAccount(
      LedgerAccountType.MERCHANT_PAYABLE,
      LedgerAccountOwnerType.MERCHANT,
      merchantId,
      'KES'
    );

    // Get current ledger balance
    const currentBalanceMinor = await this.repo.recalculateAccountBalance(merchantAcc.id);

    // Get all order summaries for this merchant
    const allSummaries = await this.repo.getAllOrderSummaries();
    // Filter by date and merchant (or simulate lines based on current payable balance)
    const relevantSummaries = allSummaries.filter((s) => {
      const calcDate = new Date(s.calculated_at);
      return calcDate >= start && calcDate <= end;
    });

    let grossOrderValueMinor = 0;
    let commissionAmountMinor = 0;
    let refundAmountMinor = 0;
    let netSettlementAmountMinor = 0;

    const lines: MerchantSettlementLine[] = [];
    const settlementId = `stl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const settlementNumber = `STL-${end.toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;

    for (const summary of relevantSummaries) {
      grossOrderValueMinor += summary.food_subtotal_minor;
      commissionAmountMinor += summary.commission_revenue_minor;
      refundAmountMinor += summary.refund_cost_minor;
      const orderNet = summary.food_subtotal_minor - summary.commission_revenue_minor - summary.refund_cost_minor;
      netSettlementAmountMinor += orderNet;

      lines.push({
        id: `stl_ln_${Date.now()}_${lines.length}`,
        settlement_id: settlementId,
        entry_type: 'ORDER',
        reference_id: summary.order_id,
        gross_amount_minor: summary.food_subtotal_minor,
        commission_amount_minor: summary.commission_revenue_minor,
        net_amount_minor: orderNet,
        description: `Order ${summary.order_number}`,
        created_at: new Date().toISOString(),
      });
    }

    // If no order summaries exist yet in the window, but merchant has an outstanding balance,
    // construct a direct settlement line matching the ledger balance
    if (lines.length === 0 && currentBalanceMinor > 0) {
      grossOrderValueMinor = currentBalanceMinor;
      netSettlementAmountMinor = currentBalanceMinor;
      lines.push({
        id: `stl_ln_${Date.now()}_0`,
        settlement_id: settlementId,
        entry_type: 'ADJUSTMENT',
        reference_id: merchantAcc.id,
        gross_amount_minor: currentBalanceMinor,
        commission_amount_minor: 0,
        net_amount_minor: currentBalanceMinor,
        description: `Outstanding payable balance settlement`,
        created_at: new Date().toISOString(),
      });
    }

    const settlement: MerchantSettlement = {
      id: settlementId,
      settlement_number: settlementNumber,
      merchant_id: merchantId,
      currency: 'KES',
      period_start: start.toISOString(),
      period_end: end.toISOString(),
      gross_order_value_minor: grossOrderValueMinor,
      commission_amount_minor: commissionAmountMinor,
      promotion_amount_minor: 0,
      refund_amount_minor: refundAmountMinor,
      adjustment_amount_minor: 0,
      net_settlement_amount_minor: Math.max(0, netSettlementAmountMinor),
      status: MerchantSettlementStatus.CALCULATED,
      approved_by: null,
      approved_at: null,
      paid_at: null,
      payment_reference: null,
      failure_reason: null,
      created_at: new Date().toISOString(),
      lines,
    };

    return await this.repo.saveSettlement(settlement, lines);
  }

  /**
   * Approves a settlement for disbursement
   */
  public async approveSettlement(settlementId: string, approvedByUserId: string): Promise<MerchantSettlement> {
    const settlement = await this.repo.findSettlementById(settlementId);
    if (!settlement) {
      throw new Error(`Settlement not found: ${settlementId}`);
    }

    if (settlement.status !== MerchantSettlementStatus.CALCULATED && settlement.status !== MerchantSettlementStatus.DRAFT) {
      throw new Error(`Cannot approve settlement in status ${settlement.status}`);
    }

    settlement.status = MerchantSettlementStatus.APPROVED;
    settlement.approved_by = approvedByUserId;
    settlement.approved_at = new Date().toISOString();

    return await this.repo.saveSettlement(settlement, settlement.lines || []);
  }

  /**
   * Executes payment of an approved settlement and posts to ledger
   */
  public async paySettlement(settlementId: string, paymentReference: string): Promise<MerchantSettlement> {
    const settlement = await this.repo.findSettlementById(settlementId);
    if (!settlement) {
      throw new Error(`Settlement not found: ${settlementId}`);
    }

    if (settlement.status !== MerchantSettlementStatus.APPROVED) {
      throw new Error(`Cannot pay settlement in status ${settlement.status}. Must be APPROVED first.`);
    }

    settlement.status = MerchantSettlementStatus.PAID;
    settlement.paid_at = new Date().toISOString();
    settlement.payment_reference = paymentReference;

    // Post to double-entry ledger
    await this.postingSvc.postMerchantSettlement(settlement);

    const saved = await this.repo.saveSettlement(settlement, settlement.lines || []);

    logger.info('Merchant settlement paid and posted to ledger', {
      metadata: {
        settlementId,
        merchantId: settlement.merchant_id,
        netAmountMinor: settlement.net_settlement_amount_minor,
        reference: paymentReference,
      },
    });

    return saved;
  }

  /**
   * Marks a settlement as failed without losing merchant funds
   */
  public async failSettlement(settlementId: string, reason: string): Promise<MerchantSettlement> {
    const settlement = await this.repo.findSettlementById(settlementId);
    if (!settlement) {
      throw new Error(`Settlement not found: ${settlementId}`);
    }

    settlement.status = MerchantSettlementStatus.FAILED;
    settlement.failure_reason = reason;

    return await this.repo.saveSettlement(settlement, settlement.lines || []);
  }
}

export const settlementService = new SettlementService();
