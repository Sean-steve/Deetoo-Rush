/**
 * DEETOO - Rider Payout Service
 * Sprint 12: Courier payout batching, M-PESA B2C execution, and ledger payout tracking
 */

import { ledgerRepository, LedgerRepository } from './ledger.repository';
import { financialPostingService, FinancialPostingService } from './financial-posting.service';
import {
  RiderPayout,
  RiderPayoutStatus,
  RiderPayoutLine,
  RiderEarningStatus,
  LedgerAccountType,
  LedgerAccountOwnerType,
} from '@deetoo/types';
import { logger } from '@deetoo/utils';

export class RiderPayoutService {
  constructor(
    private repo: LedgerRepository = ledgerRepository,
    private postingSvc: FinancialPostingService = financialPostingService
  ) {}

  /**
   * Calculates a payout for a rider based on unsettled eligible delivery earnings
   */
  public async calculatePayout(
    riderId: string,
    periodStart?: string,
    periodEnd?: string
  ): Promise<RiderPayout> {
    const end = periodEnd ? new Date(periodEnd) : new Date();
    const start = periodStart ? new Date(periodStart) : new Date(end.getTime() - 7 * 24 * 60 * 60 * 1000);

    // Get eligible earnings for this rider
    const earnings = await this.repo.findRiderEarningsByRiderId(riderId);
    const eligibleEarnings = earnings.filter(
      (e) => e.status === RiderEarningStatus.ELIGIBLE && new Date(e.created_at) <= end
    );

    const payoutId = `pyt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const payoutNumber = `PYT-${end.toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;

    let totalAmountMinor = 0;
    const lines: RiderPayoutLine[] = [];

    for (const e of eligibleEarnings) {
      totalAmountMinor += e.total_amount_minor;
      lines.push({
        id: `pyt_ln_${Date.now()}_${lines.length}`,
        payout_id: payoutId,
        earning_id: e.id,
        amount_minor: e.total_amount_minor,
        created_at: new Date().toISOString(),
      });
    }

    // If no individual earnings exist, check current rider payable balance
    if (lines.length === 0) {
      const riderAcc = await this.repo.getOrCreateAccount(
        LedgerAccountType.RIDER_PAYABLE,
        LedgerAccountOwnerType.RIDER,
        riderId,
        'KES'
      );
      const bal = await this.repo.recalculateAccountBalance(riderAcc.id);
      if (bal > 0) {
        totalAmountMinor = bal;
      }
    }

    if (totalAmountMinor <= 0) {
      throw new Error(`No eligible earnings or payable balance found for rider ${riderId}`);
    }

    const payout: RiderPayout = {
      id: payoutId,
      payout_number: payoutNumber,
      rider_id: riderId,
      currency: 'KES',
      amount_minor: totalAmountMinor,
      period_start: start.toISOString(),
      period_end: end.toISOString(),
      status: RiderPayoutStatus.DRAFT,
      provider: 'MPESA_B2C',
      provider_reference: null,
      approved_by: null,
      approved_at: null,
      paid_at: null,
      failed_at: null,
      failure_reason: null,
      created_at: new Date().toISOString(),
      lines,
    };

    return await this.repo.saveRiderPayout(payout, lines);
  }

  /**
   * Approves a rider payout
   */
  public async approvePayout(payoutId: string, approvedByUserId: string): Promise<RiderPayout> {
    const payout = await this.repo.findRiderPayoutById(payoutId);
    if (!payout) {
      throw new Error(`Payout not found: ${payoutId}`);
    }

    if (payout.status !== RiderPayoutStatus.DRAFT) {
      throw new Error(`Cannot approve payout in status ${payout.status}`);
    }

    payout.status = RiderPayoutStatus.APPROVED;
    payout.approved_by = approvedByUserId;
    payout.approved_at = new Date().toISOString();

    return await this.repo.saveRiderPayout(payout, payout.lines || []);
  }

  /**
   * Executes payout disbursement and posts to ledger
   */
  public async payPayout(payoutId: string, providerReference?: string): Promise<RiderPayout> {
    const payout = await this.repo.findRiderPayoutById(payoutId);
    if (!payout) {
      throw new Error(`Payout not found: ${payoutId}`);
    }

    if (payout.status !== RiderPayoutStatus.APPROVED) {
      throw new Error(`Cannot pay payout in status ${payout.status}. Must be APPROVED first.`);
    }

    const ref = providerReference || `MPESA-B2C-${Math.floor(10000000 + Math.random() * 90000000)}`;

    payout.status = RiderPayoutStatus.PAID;
    payout.paid_at = new Date().toISOString();
    payout.provider_reference = ref;

    // Mark constituent earnings as PAID
    if (payout.lines) {
      for (const line of payout.lines) {
        for (const e of this.repo.riderEarnings.values()) {
          if (e.id === line.earning_id) {
            e.status = RiderEarningStatus.PAID;
            e.settled_at = payout.paid_at;
            await this.repo.saveRiderEarning(e);
          }
        }
      }
    }

    // Post to double-entry ledger
    await this.postingSvc.postRiderPayout(payout);

    const saved = await this.repo.saveRiderPayout(payout, payout.lines || []);

    logger.info('Rider payout disbursed and posted to ledger', {
      metadata: {
        payoutId,
        riderId: payout.rider_id,
        amountMinor: payout.amount_minor,
        reference: ref,
      },
    });

    return saved;
  }

  /**
   * Retrieves a payout by its identifier
   */
  public async getPayoutById(payoutId: string): Promise<RiderPayout | null> {
    return await this.repo.findRiderPayoutById(payoutId);
  }

  /**
   * Marks a payout as failed without losing rider payable balance
   */
  public async failPayout(payoutId: string, reason: string): Promise<RiderPayout> {
    const payout = await this.repo.findRiderPayoutById(payoutId);
    if (!payout) {
      throw new Error(`Payout not found: ${payoutId}`);
    }

    payout.status = RiderPayoutStatus.FAILED;
    payout.failed_at = new Date().toISOString();
    payout.failure_reason = reason;

    return await this.repo.saveRiderPayout(payout, payout.lines || []);
  }
}

export const riderPayoutService = new RiderPayoutService();
