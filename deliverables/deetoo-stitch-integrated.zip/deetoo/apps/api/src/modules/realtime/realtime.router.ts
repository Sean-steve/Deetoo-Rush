/**
 * DEETOO - Realtime SSE & Polling Router
 * Exposes /api/v1/realtime/stream for live updates and /api/v1/realtime/events for polling fallback
 */

import { Router, Request, Response } from 'express';
import { orderEventBroker } from './event-broker';
import { ApiResponse } from '@deetoo/types';
import { generateRequestId } from '@deetoo/utils';

export const realtimeRouter = Router();

/**
 * GET /api/v1/realtime/stream
 * Server-Sent Events (SSE) streaming endpoint
 */
realtimeRouter.get('/stream', (req: Request, res: Response) => {
  // Set SSE Headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // Disable proxy buffering for instant delivery
  res.flushHeaders?.();

  const clientId = (req.query.clientId as string) || generateRequestId();
  const rawChannels = (req.query.channels as string) || '';
  const channels = rawChannels
    .split(',')
    .map((c) => c.trim())
    .filter(Boolean);

  // If no channels specified, subscribe to general platform announcements
  if (channels.length === 0) {
    channels.push('public');
  }

  orderEventBroker.registerClient(clientId, res, channels);

  req.on('close', () => {
    orderEventBroker.removeClient(clientId);
  });
});

/**
 * GET /api/v1/realtime/events
 * Polling fallback endpoint returning recent events for specified channel
 */
realtimeRouter.get('/events', (req: Request, res: Response) => {
  const channel = req.query.channel as string | undefined;
  const since = req.query.since as string | undefined;

  const events = orderEventBroker.getRecentEvents(channel, since);

  const response: ApiResponse<typeof events> = {
    success: true,
    data: events,
    meta: {
      timestamp: new Date().toISOString(),
      requestId: req.headers['x-request-id'] as string,
    },
  };

  res.json(response);
});

/**
 * GET /api/v1/realtime/health
 */
realtimeRouter.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    connectedClients: orderEventBroker.getConnectedClientsCount(),
    timestamp: new Date().toISOString(),
  });
});
