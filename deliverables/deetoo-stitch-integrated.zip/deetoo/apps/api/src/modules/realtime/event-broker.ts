/**
 * DEETOO - Realtime Event Broker & Outbox Dispatcher
 * Multi-channel publish-subscribe mechanism for Customer, Merchant & Admin updates (Section 29, 142)
 * Supports SSE streaming, channel filtering, in-memory buffering, and PostgreSQL outbox persistence.
 */

import { Response } from 'express';
import { RealtimeOrderEvent } from '@deetoo/types';
import { logger } from '@deetoo/utils';
import { getDbPool } from '../../db/client';

export interface SSEClient {
  id: string;
  userId?: string;
  channels: Set<string>;
  res: Response;
  createdAt: number;
}

export class OrderEventBroker {
  private clients = new Map<string, SSEClient>();
  private eventHistory: RealtimeOrderEvent[] = [];
  private pingInterval: NodeJS.Timeout | null = null;

  constructor() {
    // Keep connection alive with periodic SSE comments every 15 seconds
    this.pingInterval = setInterval(() => {
      this.broadcastPing();
    }, 15000);
    if (this.pingInterval.unref) {
      this.pingInterval.unref();
    }
  }

  /**
   * Register a new SSE subscriber client
   */
  public registerClient(id: string, res: Response, channels: string[], userId?: string): SSEClient {
    const client: SSEClient = {
      id,
      userId,
      channels: new Set(channels),
      res,
      createdAt: Date.now(),
    };

    this.clients.set(id, client);

    logger.info('Realtime client connected', {
      service: 'realtime',
      metadata: { clientId: id, channels, totalClients: this.clients.size },
    });

    // Send initial connected handshake event
    this.sendEventToClient(client, {
      type: 'connected' as any,
      channel: 'system',
      order_id: '',
      order_number: '',
      status: 'PLACED' as any,
      timestamp: new Date().toISOString(),
      data: { clientId: id, channels: Array.from(client.channels) },
    });

    return client;
  }

  /**
   * Remove a disconnected client
   */
  public removeClient(id: string) {
    if (this.clients.has(id)) {
      this.clients.delete(id);
      logger.info('Realtime client disconnected', {
        service: 'realtime',
        metadata: { clientId: id, remainingClients: this.clients.size },
      });
    }
  }

  /**
   * Add channels to an existing client
   */
  public subscribeChannels(clientId: string, channels: string[]) {
    const client = this.clients.get(clientId);
    if (client) {
      channels.forEach((c) => client.channels.add(c));
    }
  }

  /**
   * Publish an order event to target channels, outbox table, and history buffer
   */
  public async publish(channel: string, event: RealtimeOrderEvent): Promise<void> {
    // 1. Add to rolling history buffer (keep last 100 events)
    this.eventHistory.push(event);
    if (this.eventHistory.length > 100) {
      this.eventHistory.shift();
    }

    // 2. Deliver to active SSE subscribers matching channel or wildcard
    let deliveredCount = 0;
    for (const client of this.clients.values()) {
      if (client.channels.has(channel) || client.channels.has('*') || client.channels.has('all')) {
        this.sendEventToClient(client, event);
        deliveredCount++;
      }
    }

    logger.info(`Realtime event published to channel [${channel}]`, {
      service: 'realtime',
      metadata: {
        channel,
        type: event.type,
        orderId: event.order_id,
        orderNumber: event.order_number,
        status: event.status,
        deliveredCount,
      },
    });

    // 3. Persist to outbox_events table in PostgreSQL if available
    this.persistOutboxEvent(channel, event).catch((err) => {
      logger.warn('Could not write outbox event to PostgreSQL', {
        service: 'realtime',
        metadata: { error: err.message },
      });
    });
  }

  /**
   * Helper to write structured event into PostgreSQL outbox table
   */
  private async persistOutboxEvent(channel: string, event: RealtimeOrderEvent): Promise<void> {
    try {
      const pool = getDbPool();
      const client = await pool.connect();
      try {
        await client.query(
          `INSERT INTO outbox_events (id, aggregate_type, aggregate_id, event_type, payload, channel, status, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, 'PUBLISHED', CURRENT_TIMESTAMP)
           ON CONFLICT (id) DO NOTHING`,
          [
            `outbox_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
            'ORDER',
            event.order_id || 'order_unknown',
            event.type,
            JSON.stringify(event),
            channel,
          ]
        );
      } finally {
        client.release();
      }
    } catch {
      // In standalone/memory fallback mode, silent catch
    }
  }

  /**
   * Formats and writes an SSE event
   */
  private sendEventToClient(client: SSEClient, event: RealtimeOrderEvent) {
    try {
      const dataStr = JSON.stringify(event);
      client.res.write(`event: ${event.type}\n`);
      client.res.write(`data: ${dataStr}\n\n`);
    } catch (err: any) {
      logger.warn('Failed to write SSE event to client, pruning', {
        service: 'realtime',
        metadata: { clientId: client.id, error: err.message },
      });
      this.removeClient(client.id);
    }
  }

  /**
   * Broadcast periodic ping comment to prevent reverse proxies and browsers from timing out
   */
  private broadcastPing() {
    const timestamp = Date.now();
    for (const client of this.clients.values()) {
      try {
        client.res.write(`:ping ${timestamp}\n\n`);
      } catch {
        this.removeClient(client.id);
      }
    }
  }

  /**
   * Retrieve recent events for polling fallback
   */
  public getRecentEvents(channel?: string, sinceTimestamp?: string): RealtimeOrderEvent[] {
    let filtered = this.eventHistory;
    if (channel) {
      filtered = filtered.filter((e) => e.channel === channel);
    }
    if (sinceTimestamp) {
      const since = new Date(sinceTimestamp).getTime();
      filtered = filtered.filter((e) => new Date(e.timestamp).getTime() > since);
    }
    return filtered;
  }

  public getConnectedClientsCount(): number {
    return this.clients.size;
  }
}

export const orderEventBroker = new OrderEventBroker();
