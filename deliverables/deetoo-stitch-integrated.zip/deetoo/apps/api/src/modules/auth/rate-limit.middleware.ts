/**
 * DEETOO - Authentication Rate Limiter
 * Implements sliding-window rate limiting per IP and identifier (Section 57)
 */

import { Request, Response, NextFunction } from 'express';
import { AppError } from '../../middleware/error-handler';

interface RateLimitBucket {
  timestamps: number[];
}

const memoryBuckets = new Map<string, RateLimitBucket>();

// Clean up expired entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of memoryBuckets.entries()) {
    bucket.timestamps = bucket.timestamps.filter((ts) => now - ts < 300000);
    if (bucket.timestamps.length === 0) {
      memoryBuckets.delete(key);
    }
  }
}, 300000);

export function createAuthRateLimiter(options: {
  windowMs: number;
  max: number;
  keyPrefix: string;
  useIdentifier?: boolean;
}) {
  return (req: Request, res: Response, next: NextFunction) => {
    // In test environment, allow high throughput
    if (process.env.NODE_ENV === 'test' && !req.headers['x-test-rate-limit']) {
      return next();
    }

    const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown-ip';
    let key = `${options.keyPrefix}:${ip}`;

    if (options.useIdentifier && req.body) {
      const identifier = req.body.identifier || req.body.email || req.body.phone_e164;
      if (identifier) {
        key = `${options.keyPrefix}:${ip}:${String(identifier).trim().toLowerCase()}`;
      }
    }

    const now = Date.now();
    let bucket = memoryBuckets.get(key);
    if (!bucket) {
      bucket = { timestamps: [] };
      memoryBuckets.set(key, bucket);
    }

    // Keep only requests inside the sliding window
    bucket.timestamps = bucket.timestamps.filter((ts) => now - ts < options.windowMs);

    if (bucket.timestamps.length >= options.max) {
      const oldest = bucket.timestamps[0];
      const retryAfterSec = Math.ceil((oldest + options.windowMs - now) / 1000);
      res.setHeader('Retry-After', retryAfterSec);
      return next(
        new AppError(
          429,
          'RATE_LIMIT_EXCEEDED',
          `Too many attempts. Please wait ${retryAfterSec} seconds before trying again.`,
          { retry_after_seconds: retryAfterSec }
        )
      );
    }

    bucket.timestamps.push(now);
    next();
  };
}

// Pre-configured rate limiters per Section 57
export const loginRateLimiter = createAuthRateLimiter({
  keyPrefix: 'auth:login',
  windowMs: 60000, // 1 minute
  max: 10,
  useIdentifier: true,
});

export const registerRateLimiter = createAuthRateLimiter({
  keyPrefix: 'auth:register',
  windowMs: 60000,
  max: 10,
});

export const passwordResetRateLimiter = createAuthRateLimiter({
  keyPrefix: 'auth:password-reset',
  windowMs: 60000,
  max: 5,
  useIdentifier: true,
});

export const otpRateLimiter = createAuthRateLimiter({
  keyPrefix: 'auth:otp',
  windowMs: 60000,
  max: 5,
});

export const refreshRateLimiter = createAuthRateLimiter({
  keyPrefix: 'auth:refresh',
  windowMs: 60000,
  max: 30,
});
