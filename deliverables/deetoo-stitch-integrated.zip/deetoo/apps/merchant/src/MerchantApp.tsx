import { BranchSettings } from "./components/BranchSettings";
import { MerchantAccount } from "./components/MerchantAccount";
import { AccountSupport } from "../../../packages/ui/src/AccountSupport";
import { KitchenOrders } from "./components/KitchenOrders";
import {
  OperationsLayout,
  Navigation,
  ResourceState,
  StatusBadge,
  useResource,
  errorMessage,
} from "../../../packages/ui/src/workflows";
import { MerchantFinance } from "./components/MerchantFinance";
/**
 * DEETOO - Merchant Application Shell
 * Restaurant operations console with authentication, branch scoping, and RBAC (Sprint 2)
 * Compliant with Section 29, 30 & DEE-PRD-001, DEE-SEC-001, DEE-STATE-001
 */

import React, { useState, useEffect } from "react";
import {
  DeetooLogo,
  Button,
  Card,
  Badge,
  Select,
  EmptyState,
  ErrorBoundary,
  Modal,
  FormField,
  Input,
} from "../../../packages/ui/src/index";
import { AuthProvider, useAuth } from "../../../packages/auth/src/react";
import {
  BranchOperationalStatus,
  UserRole,
} from "../../../packages/types/src/index";
import {
  Store,
  ChefHat,
  Bell,
  CheckCircle2,
  ShieldCheck,
  User,
  LogOut,
  Lock,
  AlertTriangle,
  History,
  Key,
  UtensilsCrossed,
} from "lucide-react";
import { CatalogueManager } from "./components/CatalogueManager";

export function MerchantApp() {
  return (
    <AuthProvider clientApp="merchant">
      <MerchantAppInner />
    </AuthProvider>
  );
}

function MerchantAppInner() {
  const {
    user,
    isAuthenticated,
    isLoading,
    login,
    logout,
    hasRole,
    hasPermission,
    apiClient,
  } = useAuth();

  const [selectedBranch, setSelectedBranch] = useState("");
  const [storeStatus, setStoreStatus] = useState<BranchOperationalStatus>(
    BranchOperationalStatus.OPEN,
  );
  const [activeQueueTab, setActiveQueueTab] = useState<
    "PLACED" | "PREPARING" | "READY"
  >("PLACED");
  const [activeMainTab, setActiveMainTab] = useState<
    | "orders"
    | "catalogue"
    | "finance"
    | "account"
    | "branch"
    | "support"
    | "sessions"
  >("orders");
  const [prepModalOpen, setPrepModalOpen] = useState(false);
  const [prepMinutes, setPrepMinutes] = useState("20");

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [authError, setAuthError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sessions list
  const [sessions, setSessions] = useState<any[]>([]);
  const [isLoadingSessions, setIsLoadingSessions] = useState(false);

  const isMerchantAuthorized =
    hasRole(UserRole.MERCHANT_OWNER) ||
    hasRole(UserRole.MERCHANT_MANAGER) ||
    hasRole(UserRole.MERCHANT_STAFF) ||
    hasRole(UserRole.ADMIN);

  const canManageStoreStatus =
    hasRole(UserRole.MERCHANT_OWNER) ||
    hasRole(UserRole.MERCHANT_MANAGER) ||
    hasRole(UserRole.ADMIN) ||
    hasPermission("branch:status:update");

  const branches = useResource<any[]>(
    isAuthenticated && isMerchantAuthorized ? "/merchant/branches" : null,
  );
  const branch = branches.data?.find((b) => b.id === selectedBranch);
  const [branchError, setBranchError] = useState<string | null>(null);
  const [savingStatus, setSavingStatus] = useState(false);
  useEffect(() => {
    if (
      branches.data?.length &&
      !branches.data.some((b) => b.id === selectedBranch)
    )
      setSelectedBranch(branches.data[0].id);
  }, [branches.data, selectedBranch]);
  const updateStatus = async (status: string) => {
    setSavingStatus(true);
    setBranchError(null);
    try {
      await apiClient.request(
        `/merchant/branches/${encodeURIComponent(selectedBranch)}/status`,
        {
          method: "POST",
          body: JSON.stringify({
            operational_status: status,
            reason: "Merchant kitchen status update",
          }),
        },
      );
      await branches.refresh();
    } catch (e) {
      setBranchError(errorMessage(e));
    } finally {
      setSavingStatus(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setIsSubmitting(true);
    try {
      await login(loginIdentifier, loginPassword);
    } catch (err: any) {
      setAuthError(err.message || "Login failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const loadSessions = async () => {
    setIsLoadingSessions(true);
    try {
      const res = await apiClient.listSessions();
      setSessions(res.data || []);
    } catch {
      // ignore
    } finally {
      setIsLoadingSessions(false);
    }
  };

  const getStatusBadge = (status: BranchOperationalStatus) => {
    switch (status) {
      case BranchOperationalStatus.OPEN:
        return <Badge variant="success">STORE OPEN</Badge>;
      case BranchOperationalStatus.PAUSED:
        return <Badge variant="warning">PAUSED</Badge>;
      case BranchOperationalStatus.CLOSED:
        return <Badge variant="danger">CLOSED</Badge>;
      default:
        return <Badge>UNKNOWN</Badge>;
    }
  };

  // 1. UNFAUTHENTICATED STATE: Clean Merchant Login Portal
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-canvas flex flex-col justify-center items-center p-4 font-sans text-ink">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <DeetooLogo className="h-10 mx-auto  mb-3" />
            <h1 className="text-xl font-bold text-ink tracking-tight">
              Merchant Operations Console
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              Manage your kitchen, orders, and team.
            </p>
          </div>

          <Card className="bg-white border-stone-200 p-6 text-ink shadow-2xl">
            <form onSubmit={handleLogin} className="space-y-4">
              {authError && (
                <div className="p-3 bg-rose-950/80 border border-rose-800 rounded text-rose-300 text-xs flex items-center gap-2">
                  <AlertTriangle size={15} /> {authError}
                </div>
              )}

              <FormField label="Staff Email or Phone" required>
                <Input
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder="merchant.owner@deetoo.ke"
                  className="bg-canvas border-stone-200 text-ink"
                  required
                />
              </FormField>

              <FormField label="Password" required>
                <Input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="bg-canvas border-stone-200 text-ink"
                  required
                />
              </FormField>

              <Button
                type="submit"
                variant="primary"
                className="w-full cursor-pointer mt-2"
                isLoading={isSubmitting}
              >
                Sign In to Restaurant Console
              </Button>
            </form>
          </Card>
        </div>
      </div>
    );
  }

  // 2. FORBIDDEN ROLE STATE: User logged in without merchant permissions (e.g. customer)
  if (!isMerchantAuthorized) {
    return (
      <div className="min-h-screen bg-canvas flex flex-col justify-center items-center p-4 font-sans text-ink">
        <Card className="max-w-md w-full bg-white border-stone-200 p-6 text-center">
          <Lock size={36} className="mx-auto text-rose-500 mb-3" />
          <h2 className="text-base font-bold text-ink">
            403 Forbidden: Insufficient Permissions
          </h2>
          <p className="text-xs text-slate-600 mt-2 mb-4 leading-relaxed">
            Your current account (
            <span className="font-mono text-ink">{user?.email}</span>) has
            roles: [
            <span className="text-amber-400 font-mono">
              {user?.roles.join(", ")}
            </span>
            ]. Access to the Merchant Operations Console requires an active
            Merchant role.
          </p>
          <Button
            variant="danger"
            size="sm"
            onClick={logout}
            className="cursor-pointer"
          >
            Sign Out & Switch Account
          </Button>
        </Card>
      </div>
    );
  }

  // 3. AUTHENTICATED & AUTHORIZED OPERATIONAL CONSOLE
  return (
    <ErrorBoundary fallbackTitle="Merchant operations">
      <OperationsLayout
        title="Kitchen operations"
        userName={user?.name || user?.email}
        onLogout={logout}
        navigation={
          <Navigation
            active={activeMainTab}
            onChange={(id) => {
              setActiveMainTab(id as typeof activeMainTab);
              if (id === "sessions") void loadSessions();
            }}
            items={[
              { id: "orders", label: "Kitchen display" },
              { id: "catalogue", label: "Menu & availability" },
              { id: "finance", label: "Finance & settlements" },
              { id: "account", label: "Business & team" },
              { id: "branch", label: "Branch settings" },
              { id: "sessions", label: "Security & sessions" },
              { id: "support", label: "Support" },
            ]}
          />
        }
      >
        <ResourceState resource={branches}>
          <Card className="mb-6">
            <div className="flex flex-wrap items-end gap-4">
              <div className="flex-1 min-w-48">
                <FormField label="Kitchen branch">
                  <Select
                    value={selectedBranch}
                    onChange={(e) => setSelectedBranch(e.target.value)}
                  >
                    <option value="">Select branch</option>
                    {branches.data?.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </FormField>
              </div>
              {branch && (
                <>
                  <StatusBadge status={branch.operational_status} />
                  <div className="flex gap-2">
                    {["OPEN", "PAUSED", "CLOSED"].map((status) => (
                      <Button
                        key={status}
                        variant="outline"
                        disabled={
                          !canManageStoreStatus ||
                          savingStatus ||
                          Boolean(branches.error)
                        }
                        onClick={() => updateStatus(status)}
                      >
                        {status.toLowerCase()}
                      </Button>
                    ))}
                  </div>
                </>
              )}
            </div>
            {branchError && (
              <p role="alert" className="text-rose-700 mt-3">
                {branchError}
              </p>
            )}
          </Card>
        </ResourceState>
        {selectedBranch && activeMainTab === "orders" && (
          <KitchenOrders key={selectedBranch} branchId={selectedBranch} />
        )}
        {selectedBranch && activeMainTab === "catalogue" && (
          <CatalogueManager
            key={selectedBranch}
            currentBranchId={selectedBranch}
          />
        )}
        {branch && activeMainTab === "branch" && (
          <BranchSettings
            key={branch.id}
            branchId={branch.id}
            canManage={canManageStoreStatus}
            onChanged={branches.refresh}
          />
        )}
        {branch && activeMainTab === "account" && (
          <MerchantAccount
            key={branch.merchant_id}
            merchantId={branch.merchant_id}
            branches={branches.data || []}
            canManage={canManageStoreStatus}
          />
        )}
        {activeMainTab === "support" && <AccountSupport />}
        {branch && activeMainTab === "finance" && (
          <MerchantFinance merchantId={branch.merchant_id} />
        )}
        {activeMainTab === "sessions" && (
          <Card className="bg-white">
            <h3 className="text-sm font-bold text-slate-900 mb-2 flex items-center gap-2">
              <History size={16} className="text-brand" /> Merchant Staff
              Active Sessions
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Active login tokens for staff member {user?.email}. Revoking
              sessions invalidates all refresh tokens and active API tokens.
            </p>
            <div className="divide-y divide-slate-100 text-xs">
              {sessions.map((s) => (
                <div
                  key={s.id}
                  className="py-3 flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-800">
                        {s.id.substring(0, 16)}...
                      </span>
                      {s.current && (
                        <Badge variant="success" className="text-[10px]">
                          Current Session
                        </Badge>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1">
                      IP: {s.ip_address || "127.0.0.1"} | Device:{" "}
                      {s.device_info || "Console"}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </OperationsLayout>
    </ErrorBoundary>
  );
}
