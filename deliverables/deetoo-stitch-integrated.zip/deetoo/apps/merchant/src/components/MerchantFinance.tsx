import React from "react";
import {
  Card,
  Price,
  Button,
  EmptyState,
} from "../../../../packages/ui/src/index";
import {
  MetricCard,
  PageHeading,
  ResourceState,
  StatusBadge,
  useResource,
} from "../../../../packages/ui/src/workflows";
export function MerchantFinance({ merchantId }: { merchantId: string }) {
  const statement = useResource<any>(
    `/finance/merchant/statement?merchant_id=${encodeURIComponent(merchantId)}`,
  );
  return (
    <>
      <PageHeading
        title="Finance & settlements"
        action={
          <Button variant="outline" onClick={statement.refresh}>
            Refresh statement
          </Button>
        }
      />
      <ResourceState resource={statement}>
        {statement.data && (
          <>
            <MetricCard
              label="Payable balance"
              value={<Price minor={statement.data.payable_balance_minor} />}
            />
            <div className="grid gap-4 mt-5">
              {statement.data.settlements?.map((settlement: any) => (
                <Card key={settlement.id}>
                  <div className="flex justify-between">
                    <h2 className="font-bold">
                      {settlement.period_start} — {settlement.period_end}
                    </h2>
                    <StatusBadge status={settlement.status} />
                  </div>
                  <p className="mt-3">
                    {settlement.net_settlement_amount_minor != null && (
                      <Price minor={settlement.net_settlement_amount_minor} />
                    )}
                  </p>
                </Card>
              ))}
              {!statement.data.settlements?.length && (
                <EmptyState
                  title="No settlements yet"
                  description="Calculated settlements will appear here."
                />
              )}
            </div>
          </>
        )}
      </ResourceState>
    </>
  );
}
